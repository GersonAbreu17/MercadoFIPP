package com.example.MercadoFIPP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MercadoFippApplicationTests {

	@Test
	void contextLoads() {
	}

}
