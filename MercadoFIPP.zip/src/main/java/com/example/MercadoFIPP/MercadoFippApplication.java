package com.example.MercadoFIPP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MercadoFippApplication {

	public static void main(String[] args) {
		SpringApplication.run(MercadoFippApplication.class, args);
	}

}
